A basic todo app using "Django".

To try this code, simply clone this repo and type in terminal:
## cd todo_django
## python manage.py runserver

#### Note: Make sure python and virtual environment is installed in your system.
#### Before running the script, make sure to activate venv and download django.
